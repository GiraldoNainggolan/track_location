pip install phonenumbers

pip install opencage

pip install folium
